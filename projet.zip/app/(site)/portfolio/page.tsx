import type { Metadata } from "next";

import { PageShell } from "@/components/page-shell";
import { Badge, Tag } from "@/components/ui/badge";
import { Callout } from "@/components/ui/callout";
import { Card, CardBody } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { ButtonLink } from "@/components/ui/button";
import { portfolioProjects } from "@/lib/portfolio";
import { StructuredData } from "@/components/structured-data";
import { createPageMetadata } from "@/lib/seo";

export const metadata: Metadata = createPageMetadata(
  "Portfolio",
  "Découvrez des exemples de projets qui montrent la qualité de production et la finesse d’exécution de 2DK IT.",
  "/portfolio",
);

const portfolioStructuredData = {
  "@context": "https://schema.org",
  "@type": "CollectionPage",
  name: "Portfolio 2DK IT",
  url: "https://www.2dk-it.fr/portfolio",
  description:
    "Découvrez des exemples de projets qui montrent la qualité de production et la finesse d’exécution de 2DK IT.",
  mainEntity: {
    "@type": "ItemList",
    itemListElement: portfolioProjects.map((project, index) => ({
      "@type": "ListItem",
      position: index + 1,
      name: project.name,
      item: {
        "@type": "CreativeWork",
        name: project.name,
        additionalType: project.type,
        description: project.context,
        url: project.href ? `https://www.2dk-it.fr${project.href}` : "https://www.2dk-it.fr/portfolio",
      },
    })),
  },
  inLanguage: "fr-FR",
};

export default function PortfolioPage() {
  return (
    <PageShell
      eyebrow="Portfolio"
      title="Des projets sobres, lisibles et pensés pour rassurer rapidement"
      description="Chaque projet montre le niveau de finition, la logique de production et la capacité à faire évoluer une base propre."
    >
      <StructuredData data={portfolioStructuredData} />

      <div className="flex flex-col gap-14 lg:gap-18">
        <section className="space-y-5">
          <div className="flex flex-wrap items-center gap-3">
            <Badge tone="accent">Réalisations</Badge>
            <Tag>Cas client</Tag>
            <Tag>Mockups</Tag>
            <Tag>Support IT</Tag>
          </div>

          <div className="grid gap-6 lg:grid-cols-[1fr_0.92fr] lg:items-center">
            <div className="space-y-4">
              <p className="ds-eyebrow">Intro</p>
              <h2 className="text-3xl font-semibold tracking-tight text-white sm:text-4xl">
                Un portfolio pensé pour montrer le niveau de finition, pas pour faire du bruit.
              </h2>
              <p className="text-base leading-7 text-slate-300">
                Les projets sont présentés avec un langage clair: contexte, problème, solution et bénéfice.
                L’objectif est de rendre la qualité visible immédiatement.
              </p>
            </div>

            <Callout tone="neutral" className="space-y-3">
              <p className="ds-kicker">Architecture de contenu</p>
              <p className="text-sm leading-6 text-slate-100">
                La source de données est centralisée dans un tableau TypeScript pour ajouter facilement de nouveaux projets.
              </p>
            </Callout>
          </div>
        </section>

        <Separator />

        <section className="space-y-6">
          <div className="space-y-3 max-w-2xl">
            <p className="ds-eyebrow">Grille de projets</p>
            <h2 className="text-3xl font-semibold tracking-tight text-white sm:text-4xl">
              Des cartes élégantes, avec l’essentiel de l’information.
            </h2>
            <p className="text-base leading-7 text-slate-300">
              Chaque projet suit la même structure pour faciliter la lecture et la comparaison.
            </p>
          </div>

          <div className="grid gap-5 xl:grid-cols-3">
            {portfolioProjects.map((project) => (
              <Card key={project.name} className="overflow-hidden p-0">
                <div className={`h-48 bg-linear-to-br ${project.imageAccent} p-5 sm:h-52 sm:p-6`}>
                  <div className="flex h-full flex-col justify-between rounded-3xl border border-white/10 bg-black/20 p-4 backdrop-blur-sm">
                    <div className="flex items-start justify-between gap-3">
                      <Tag>{project.type}</Tag>
                      <span className="rounded-full border border-white/10 bg-white/5 px-3 py-1 text-[0.65rem] font-semibold uppercase tracking-[0.24em] text-slate-300">
                        {project.imageLabel}
                      </span>
                    </div>
                    <div className="grid gap-3 sm:grid-cols-3">
                      <div className="h-16 rounded-2xl border border-white/10 bg-white/4" />
                      <div className="h-16 rounded-2xl border border-white/10 bg-white/6" />
                      <div className="h-16 rounded-2xl border border-white/10 bg-white/4" />
                    </div>
                  </div>
                </div>

                <CardBody className="space-y-5 p-6 sm:p-7">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between gap-3">
                      <h3 className="text-2xl font-semibold tracking-tight text-white">{project.name}</h3>
                      <Badge tone="subtle">{project.type}</Badge>
                    </div>
                    <p className="text-sm leading-6 text-slate-300">{project.context}</p>
                  </div>

                  <div className="space-y-3 text-sm leading-6 text-slate-300">
                    <div>
                      <p className="text-xs font-semibold uppercase tracking-[0.24em] text-slate-500">Problème</p>
                      <p className="mt-2">{project.problem}</p>
                    </div>
                    <div>
                      <p className="text-xs font-semibold uppercase tracking-[0.24em] text-slate-500">Solution</p>
                      <p className="mt-2">{project.solution}</p>
                    </div>
                    <div>
                      <p className="text-xs font-semibold uppercase tracking-[0.24em] text-slate-500">Résultat</p>
                      <p className="mt-2">{project.result}</p>
                    </div>
                  </div>

                  {project.href ? (
                    <ButtonLink href={project.href} variant="secondary" className="w-full">
                      Voir le projet
                    </ButtonLink>
                  ) : null}
                </CardBody>
              </Card>
            ))}
          </div>
        </section>

        <section className="grid gap-6 lg:grid-cols-[0.95fr_1.05fr] lg:items-start">
          <div className="space-y-4">
            <p className="ds-eyebrow">Pourquoi ce format</p>
            <h2 className="text-3xl font-semibold tracking-tight text-white sm:text-4xl">
              Une structure simple à enrichir sans casser la cohérence.
            </h2>
            <p className="text-base leading-7 text-slate-300">
              Le tableau TypeScript permet d’ajouter un projet, un mockup ou une capture plus tard sans refondre la page.
            </p>
          </div>

          <Callout tone="accent" className="space-y-3">
            <p className="ds-kicker">Ajout futur</p>
            <p className="text-sm leading-6 text-slate-100">
              Vous pourrez migrer cette source vers un CMS headless sans changer la logique d’affichage.
            </p>
          </Callout>
        </section>

        <section>
          <Callout tone="accent" className="grid gap-4 lg:grid-cols-[1.05fr_0.95fr] lg:items-center">
            <div className="space-y-3">
              <p className="ds-kicker">Contact</p>
              <h2 className="text-3xl font-semibold tracking-tight text-white sm:text-4xl">
                Vous avez un projet à présenter ? On peut en parler.
              </h2>
              <p className="text-sm leading-6 text-slate-100">
                Une présentation claire du contexte et du besoin suffit pour démarrer.
              </p>
            </div>

            <div className="flex flex-col gap-3 sm:flex-row lg:justify-end">
              <ButtonLink href="/contact" variant="primary">
                Demander un devis
              </ButtonLink>
              <ButtonLink href="/services" variant="ghost">
                Voir les services
              </ButtonLink>
            </div>
          </Callout>
        </section>
      </div>
    </PageShell>
  );
}