import type { Metadata } from "next";
import Link from "next/link";

import { LegalPage } from "@/components/legal-page";
import { createPageMetadata } from "@/lib/seo";
import { companyName, dpoEmail } from "@/lib/site";

export const metadata: Metadata = createPageMetadata(
  "Politique de confidentialité",
  "Politique de confidentialité de 2DK IT, prête à compléter avec les informations de traitement.",
  "/politique-de-confidentialite",
);

export default function PrivacyPolicyPage() {
  return (
    <LegalPage
      eyebrow="Politique de confidentialité"
      title="Politique de confidentialité"
      description="Cette politique explique comment 2DK IT collecte, utilise et protège les données personnelles."
      lastUpdated="21 juin 2026"
    >
      <section className="space-y-4">
        <h2 className="text-3xl font-semibold tracking-tight text-white">1. Responsable du traitement</h2>
        <p className="text-sm leading-7 text-slate-300">
          Le responsable du traitement est <strong className="text-white">{companyName}</strong>, contactable à
          <strong className="text-white"> {dpoEmail}</strong>.
        </p>
      </section>

      <section className="space-y-4">
        <h2 className="text-3xl font-semibold tracking-tight text-white">2. Données collectées</h2>
        <p className="text-sm leading-7 text-slate-300">
          Nous pouvons collecter les données transmises via le formulaire de contact: nom, entreprise, email,
          téléphone, besoin et message.
        </p>
      </section>

      <section className="space-y-4">
        <h2 className="text-3xl font-semibold tracking-tight text-white">3. Finalités et base légale</h2>
        <p className="text-sm leading-7 text-slate-300">
          Les données sont utilisées pour répondre aux demandes, préparer des échanges commerciaux et assurer
          le suivi des échanges. La base légale est l’intérêt légitime ou l’exécution de mesures précontractuelles,
          selon le contexte.
        </p>
      </section>

      <section className="space-y-4">
        <h2 className="text-3xl font-semibold tracking-tight text-white">4. Durée de conservation</h2>
        <p className="text-sm leading-7 text-slate-300">
          Les données sont conservées pendant une durée à définir selon la finalité, puis supprimées ou archivées
          conformément aux obligations applicables.
        </p>
      </section>

      <section className="space-y-4">
        <h2 className="text-3xl font-semibold tracking-tight text-white">5. Vos droits</h2>
        <p className="text-sm leading-7 text-slate-300">
          Vous disposez des droits d’accès, de rectification, d’effacement, d’opposition, de limitation et de
          portabilité lorsque cela s’applique. Pour exercer vos droits, écrivez à
          <strong className="text-white"> {dpoEmail}</strong>.
        </p>
      </section>

      <section className="space-y-4">
        <h2 className="text-3xl font-semibold tracking-tight text-white">6. Liens utiles</h2>
        <p className="text-sm leading-7 text-slate-300">
          Consultez aussi les <Link className="text-blue-300 underline decoration-white/20 underline-offset-4" href="/mentions-legales">mentions légales</Link>, la <Link className="text-blue-300 underline decoration-white/20 underline-offset-4" href="/politique-de-cookies">politique de cookies</Link> et les <Link className="text-blue-300 underline decoration-white/20 underline-offset-4" href="/cgu">CGU</Link>.
        </p>
      </section>
    </LegalPage>
  );
}