import { PageShell } from "@/components/page-shell";
import { Badge, Tag } from "@/components/ui/badge";
import { Callout } from "@/components/ui/callout";
import { Card, CardBody, CardHeader } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { ContactForm } from "@/components/contact-form";
import { StructuredData } from "@/components/structured-data";
import { siteConfig } from "@/lib/site";
import { createPageMetadata } from "@/lib/seo";

export const metadata = createPageMetadata(
  "Contact",
  "Contactez 2DK IT avec un formulaire simple, fiable et crédible.",
  "/contact",
);

const contactStructuredData = {
  "@context": "https://schema.org",
  "@type": "ContactPage",
  name: "Contact 2DK IT",
  url: "https://www.2dk-it.fr/contact",
  description:
    "Contactez 2DK IT avec un formulaire simple, fiable et crédible.",
  mainEntity: {
    "@type": "Organization",
    name: "2DK IT",
    url: "https://www.2dk-it.fr/",
    email: "contact@2dk-it.fr",
    contactPoint: {
      "@type": "ContactPoint",
      contactType: "customer service",
      email: "contact@2dk-it.fr",
      availableLanguage: ["fr"],
    },
  },
  inLanguage: "fr-FR",
};

export default function ContactPage() {
  return (
    <PageShell
      eyebrow="Contact"
      title="Une page de contact pensée pour convertir sans friction"
      description="Coordonnées, délai de réponse, RGPD clair et formulaire validé côté client comme côté serveur."
    >
      <StructuredData data={contactStructuredData} />

      <div className="flex flex-col gap-14 lg:gap-18">
        <div className="flex flex-wrap items-center gap-3">
          <Badge tone="accent">Lead qualifié</Badge>
          <Tag>Réponse rapide</Tag>
          <Tag>Contact B2B</Tag>
        </div>

        <section className="grid gap-6 lg:grid-cols-[0.95fr_1.05fr] lg:items-start">
          <div className="space-y-4">
            <p className="ds-eyebrow">Coordonnées</p>
            <h2 className="text-3xl font-semibold tracking-tight text-white sm:text-4xl">
              Un contact direct, avec une réponse claire et rapide.
            </h2>
            <p className="text-base leading-7 text-slate-300">
              {siteConfig.tagline}
            </p>

            <Callout tone="accent" className="space-y-3">
              <p className="ds-kicker">Délai de réponse</p>
              <p className="text-sm leading-6 text-slate-100">
                {siteConfig.contactDetails.responseTime}
              </p>
              <p className="text-sm leading-6 text-slate-100">{siteConfig.contactDetails.availability}</p>
            </Callout>
          </div>

          <div className="grid gap-4 sm:grid-cols-3 lg:grid-cols-1 xl:grid-cols-3">
            {siteConfig.contactLines.map((line) => (
              <Card key={line.label}>
                <CardHeader>
                  <Tag>{line.label}</Tag>
                  <h3 className="ds-subheading text-xl">{line.label}</h3>
                </CardHeader>
                <CardBody>
                  <p className="text-sm leading-6 text-slate-300">{line.value}</p>
                </CardBody>
              </Card>
            ))}
          </div>
        </section>

        <Separator />

        <section className="grid gap-5 lg:grid-cols-[1.2fr_0.8fr]">
          <Card>
            <CardHeader>
              <Tag>Formulaire</Tag>
              <h2 className="ds-subheading text-xl">Demande de contact</h2>
            </CardHeader>
            <CardBody>
              <ContactForm />

              <Callout tone="neutral" className="mt-6">
                <p className="text-sm leading-6 text-slate-100">
                  Mention RGPD: vos données sont utilisées uniquement pour traiter votre demande et vous recontacter.
                </p>
              </Callout>
            </CardBody>
          </Card>

          <Card>
            <CardHeader>
              <Tag>Coordonnées</Tag>
              <h2 className="ds-subheading text-xl">Informations utiles</h2>
            </CardHeader>
            <CardBody className="space-y-4">
              <div className="space-y-3 rounded-3xl border border-white/10 bg-white/[0.03] p-5">
                <p className="text-xs font-semibold uppercase tracking-[0.24em] text-slate-500">
                  Email professionnel
                </p>
                <p className="text-base font-medium text-white">{siteConfig.contactDetails.email}</p>
                <Separator className="my-4" />
                <p className="text-xs font-semibold uppercase tracking-[0.24em] text-slate-500">
                  Téléphone
                </p>
                <p className="text-base font-medium text-white">{siteConfig.contactDetails.phone}</p>
              </div>

              <Callout>
                <p className="text-sm leading-6 text-slate-200">
                  Le formulaire est protégé par un champ anti-spam discret et une validation côté navigateur et serveur.
                </p>
              </Callout>
            </CardBody>
          </Card>
        </section>
      </div>
    </PageShell>
  );
}