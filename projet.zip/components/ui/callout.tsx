import type { HTMLAttributes, ReactNode } from "react";

import { cn } from "@/lib/cn";

type CalloutTone = "default" | "accent" | "neutral";

type CalloutProps = HTMLAttributes<HTMLDivElement> & {
  children: ReactNode;
  tone?: CalloutTone;
};

const toneStyles: Record<CalloutTone, string> = {
  default: "border-border bg-surface/80 text-slate-200",
  accent: "border-primary/30 bg-primary-soft text-white",
  neutral: "border-border-strong bg-surface-strong text-slate-100",
};

export function Callout({ children, tone = "default", className, ...props }: CalloutProps) {
  return (
    <div
      className={cn(
        "rounded-3xl border p-5 shadow-subtle sm:p-6",
        toneStyles[tone],
        className,
      )}
      {...props}
    >
      {children}
    </div>
  );
}