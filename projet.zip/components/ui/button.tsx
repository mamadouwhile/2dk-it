import type { ButtonHTMLAttributes, AnchorHTMLAttributes, ReactNode } from "react";

import { cn } from "@/lib/cn";

type ButtonVariant = "primary" | "secondary" | "ghost";

type SharedProps = {
  variant?: ButtonVariant;
  className?: string;
  children: ReactNode;
};

type ButtonAsButton = SharedProps & ButtonHTMLAttributes<HTMLButtonElement>;
type ButtonAsLink = SharedProps & AnchorHTMLAttributes<HTMLAnchorElement> & { href: string };

const variantStyles: Record<ButtonVariant, string> = {
  primary:
    "border border-primary/35 bg-primary text-white shadow-[0_14px_40px_rgba(10,132,255,0.18)] hover:border-primary/55 hover:bg-primary-strong",
  secondary:
    "border border-border-strong bg-surface-strong text-white hover:border-white/20 hover:bg-[#18233a]",
  ghost:
    "border border-transparent bg-transparent text-slate-200 hover:border-white/10 hover:bg-white/5 hover:text-white",
};

const baseStyles =
  "inline-flex items-center justify-center gap-2 rounded-full px-5 py-3 text-sm font-semibold tracking-tight transition duration-200 ease-out focus-visible:outline-none focus-visible:ring-0 disabled:pointer-events-none disabled:opacity-50";

function buttonClassName(variant: ButtonVariant, className?: string) {
  return cn(baseStyles, variantStyles[variant], className);
}

export function Button({
  variant = "primary",
  className,
  children,
  ...props
}: ButtonAsButton) {
  return (
    <button className={buttonClassName(variant, className)} {...props}>
      {children}
    </button>
  );
}

export function ButtonLink({
  variant = "primary",
  className,
  children,
  href,
  ...props
}: ButtonAsLink) {
  return (
    <a href={href} className={buttonClassName(variant, className)} {...props}>
      {children}
    </a>
  );
}