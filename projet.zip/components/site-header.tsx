"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";

import { siteConfig } from "@/lib/site";

function isCurrentPath(pathname: string | null, href: string) {
  if (!pathname) {
    return false;
  }

  if (href === "/") {
    return pathname === "/";
  }

  return pathname === href || pathname.startsWith(`${href}/`);
}

export function SiteHeader() {
  const pathname = usePathname();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const closeMobileMenu = () => setMobileMenuOpen(false);

  return (
    <header className="sticky top-0 z-50 border-b border-white/10 bg-slate-950/78 backdrop-blur-xl supports-backdrop-filter:bg-slate-950/70">
      <div className="mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-3 py-4">
          <Link href="/" className="group flex min-w-0 items-center gap-3" onClick={closeMobileMenu}>
            <span className="flex h-11 w-11 items-center justify-center rounded-2xl border border-white/10 bg-white/5 text-sm font-semibold tracking-[0.3em] text-white shadow-[0_0_0_1px_rgba(10,132,255,0.18)] transition duration-200 group-hover:border-primary/40 group-hover:text-[#b8dcff]">
              2DK
            </span>
            <span className="flex min-w-0 flex-col leading-tight">
              <span className="truncate text-sm font-semibold uppercase tracking-[0.28em] text-white">
                {siteConfig.name}
              </span>
              <span className="truncate text-xs text-slate-400">B2B development & IT services</span>
            </span>
          </Link>

          <nav className="hidden items-center gap-1 rounded-full border border-white/10 bg-white/5 p-1 lg:flex">
            {siteConfig.navigation.map((item) => {
              const active = isCurrentPath(pathname, item.href);

              return (
                <Link
                  key={item.href}
                  href={item.href}
                  aria-current={active ? "page" : undefined}
                  onClick={closeMobileMenu}
                  className={`rounded-full px-4 py-2 text-sm font-medium transition ${
                    active
                      ? "bg-white text-slate-950"
                      : "text-slate-300 hover:bg-white/10 hover:text-white"
                  }`}
                >
                  {item.label}
                </Link>
              );
            })}
          </nav>

          <div className="flex items-center gap-2 sm:gap-3">
            <Link
              href="/contact"
              onClick={closeMobileMenu}
              className="inline-flex items-center justify-center rounded-full border border-primary/30 bg-primary px-4 py-2 text-sm font-semibold text-white shadow-[0_12px_40px_rgba(10,132,255,0.22)] transition duration-200 hover:-translate-y-0.5 hover:bg-primary-strong sm:px-5 sm:py-2.5"
            >
              <span className="hidden sm:inline">Demander un devis</span>
              <span className="sm:hidden">Devis</span>
            </Link>

            <button
              type="button"
              aria-label={mobileMenuOpen ? "Fermer le menu" : "Ouvrir le menu"}
              aria-expanded={mobileMenuOpen}
              aria-controls="mobile-navigation"
              className="inline-flex h-11 w-11 items-center justify-center rounded-2xl border border-white/10 bg-white/5 text-slate-100 transition duration-200 hover:border-white/20 hover:bg-white/10 lg:hidden"
              onClick={() => setMobileMenuOpen((value) => !value)}
            >
              <span className="sr-only">
                {mobileMenuOpen ? "Fermer le menu" : "Ouvrir le menu"}
              </span>
              <span className="flex flex-col gap-1.5">
                <span
                  className={`h-0.5 w-5 rounded-full bg-current transition duration-200 ${mobileMenuOpen ? "translate-y-2 rotate-45" : ""}`}
                />
                <span
                  className={`h-0.5 w-5 rounded-full bg-current transition duration-200 ${mobileMenuOpen ? "opacity-0" : ""}`}
                />
                <span
                  className={`h-0.5 w-5 rounded-full bg-current transition duration-200 ${mobileMenuOpen ? "-translate-y-2 -rotate-45" : ""}`}
                />
              </span>
            </button>
          </div>
        </div>
      </div>

      <div
        id="mobile-navigation"
        className={`overflow-hidden border-t border-white/10 bg-slate-950/95 transition-all duration-200 ease-out lg:hidden ${mobileMenuOpen ? "max-h-96 opacity-100" : "pointer-events-none max-h-0 opacity-0"}`}
      >
        <div className="mx-auto w-full max-w-7xl px-4 py-4 sm:px-6">
          <div className="grid gap-2">
          {siteConfig.navigation.map((item) => {
            const active = isCurrentPath(pathname, item.href);

            return (
              <Link
                key={item.href}
                href={item.href}
                aria-current={active ? "page" : undefined}
                onClick={closeMobileMenu}
                className={`rounded-2xl px-4 py-3 text-sm font-medium transition duration-200 ${
                  active
                    ? "bg-white text-slate-950"
                    : "bg-white/5 text-slate-300 hover:bg-white/10 hover:text-white"
                }`}
              >
                {item.label}
              </Link>
            );
          })}

          <Link
            href="/contact"
            onClick={closeMobileMenu}
            className="mt-2 inline-flex items-center justify-center rounded-2xl border border-primary/30 bg-primary px-4 py-3 text-sm font-semibold text-white shadow-[0_12px_32px_rgba(10,132,255,0.2)] transition duration-200 hover:bg-primary-strong"
          >
            Demander un devis
          </Link>
          </div>
        </div>
      </div>
    </header>
  );
}